from flask import Flask,render_template,request
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
import pickle
from nltk.corpus import stopwords
app = Flask(__name__)

model = pickle.load(open('model_save.pkl','rb'))
cv = pickle.load(open('cv.pkl','rb'))


def clean_message(message):
    stp_words = stopwords.words('english')
    clean_message = " ".join(word for word in message.split() if word not in stp_words)
    return clean_message

def predict_sentiment(message_text):
    #Preprocess the input review
    cleaned_message = clean_message(message_text)
    #Transfrom the review using the TF-IDF vectorizer
    transformed_message = cv.transform([cleaned_message]).toarray()
    #Predict sentiment using the trained model
    prediction = model.predict(transformed_message)

    if prediction[0] == 1:
        return 'Spam'
    else:
        return 'Not-Spam'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/result', methods = ['POST'])
def result():
    if request.method == 'POST':
        message = request.form['message']
        result = predict_sentiment(message)
        return render_template('result.html',message = message, result = result)

if __name__ == '__main__':
    app.run(debug = True)